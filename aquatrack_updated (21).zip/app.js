const today=new Date().toISOString().slice(0,10),K='aquatrack_procurement_db_v2';
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=n=>'₱'+Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const ST=['Pending','Confirmed','Rejected'];
const POS=['Open','Pending','Paid','Partial','Completed','Cancelled'],POCOL=['#0b5fa5','#5a35b8','#d4a017','#d9772f','#2e9e2e','#888'];
/* ---------- MODULE DEFINITIONS (tables + forms) ---------- */
const M={
suppliers:{t:'Supplier Management',s:'Add, update and deactivate suppliers',f:[['name','Supplier Name','text'],['contact','Contact Person','text'],['phone','Phone','text'],['email','Email','text'],['address','Address','text'],['status','Status','sel',['Active','Inactive']]]},
items:{t:'Warehouse Inventory',s:'Main warehouse stock – empty containers, filters, filtration tanks, caps, seals, labels',f:[['name','Item Name','text'],['cat','Category','sel',['Empty Container','Filter','Caps','Seals','Label','Filtration Tank']],['unit','Unit','sel',['pcs','liters','gallons','box']],['stock','Stock on Hand','num'],['reorder','Reorder Level','num']]},
pl:{t:'Supplier Price List',s:'The price each company charges for each material',f:[['supplier','Supplier','ref','suppliers'],['item','Material','ref','items'],['price','Unit Price','num']]},
pr:{t:'Purchase Request',pre:'PR',s:'Internal requests for items to buy',f:[['item','Material','ref','items'],['qty','Quantity','num'],['date','Date','date'],['status','Status','sel',[...ST,'RFQ Sent','Completed']]],
 after:r=>{if(r.status=='Pending')r.status='Confirmed'},
 a:[['Create RFQ',r=>openForm('rfq',0,{_pr:r.id,item:r.item,qty:r.qty}),r=>r.status=='Confirmed'&&!D.rfq.some(x=>x.pr==r.id)]]},
rfq:{t:'Request for Quotation',pre:'RFQ',s:'Ask suppliers for a price on a material',f:[['item','Material','ref','items'],['qty','Quantity','num'],['supplier','Supplier','ref','suppliers'],['due','Due Date','date'],['status','Status','sel',['Sent','Responded','Finished']]],
 x:[['Supplier Prices Received',r=>{const q=[...new Map(D.quo.filter(x=>{const f=D.rfq.find(y=>y.id==x.rfq);return f&&grp(f)==grp(r)}).map(x=>[x.supplier,x])).values()];if(!q.length){const l=listed(r.supplier,r.item);return'<small>Waiting for supplier reply…'+(l!==undefined?' Listed price: <b>'+fmt(l)+'</b>/unit':'')+'</small>'}const mn=Math.min(...q.map(x=>x.price));return q.map(x=>`${esc(lbl('suppliers',x.supplier))}: <b>${fmt(x.price)}</b>/unit · ${fmt(tot(x))} total${x.price==mn&&q.length>1?' <span class="pill g1">Lowest</span>':''}`).join('<br>')}]],
 a:[['Add Quotation',r=>openForm('quo',0,{rfq:r.id,supplier:r.supplier,item:r.item,qty:r.qty,price:listed(r.supplier,r.item)??(([...D.quo].reverse().find(x=>x.supplier==r.supplier&&x.item==r.item))||{}).price}),r=>r.status!='Finished']],after:r=>{const p=D.pr.find(x=>x.id==r.pr);if(p)p.status='RFQ Sent'}},
quo:{t:'Quotation',pre:'QT',s:'Supplier price offers',f:[['rfq','RFQ','ref','rfq'],['supplier','Supplier','ref','suppliers'],['item','Material','ref','items'],['qty','Quantity','num'],['price','Unit Price','num'],['status','Status','sel',['Received','Accepted','Rejected']]],tot:1,
 a:[['Create PO',r=>openForm('po',0,{supplier:r.supplier,item:r.item,qty:r.qty,price:r.price,_quo:r.id}),r=>r.status=='Received'],['Reject',r=>{if(confirm('Reject this quotation?')){r.status='Rejected';save();go()}},r=>r.status=='Received']],after:r=>{const f=D.rfq.find(x=>x.id==r.rfq);if(f&&f.status=='Sent')f.status='Responded'}},
po:{t:'Purchase Order',pre:'PO',s:'Confirmed orders sent to suppliers',f:[['supplier','Supplier','ref','suppliers'],['item','Material','ref','items'],['qty','Quantity','num'],['price','Unit Price','num'],['date','Order Date','date'],['status','Status','sel',POS]],tot:1,nodel:r=>!['Open','Cancelled'].includes(r.status),
 a:[['Confirm',r=>{if(confirm('Confirm '+r.no+' ('+fmt(tot(r))+')?\n\nIt will be sent to Finance for payment.')){r.status='Pending';const i=ins('inv',{po:r.id,amount:tot(r),due:today,status:'Payment Requested'});ins('pq',{inv:i.id,amount:i.amount,date:today,status:'Pending'});save();go();toast(r.no+' confirmed and sent to Finance. Next: Finance pays it under Finance → Payment Requests.')}},r=>r.status=='Open'],
 ['Cancel',r=>{if(confirm('Cancel '+r.no+'?\n\nThe order will not be sent to the supplier.')){r.status='Cancelled';save();go();toast(r.no+' cancelled.')}},r=>r.status=='Open']],after:r=>{const q=D.quo.find(x=>x.id==r._quo);if(!q)return;q.status='Accepted';const f=D.rfq.find(x=>x.id==q.rfq);if(f){const same=x=>{const g=D.rfq.find(y=>y.id==x.rfq);return g&&grp(g)==grp(f)};D.quo.forEach(o=>{if(o.id!=q.id&&same(o)&&o.status=='Received')o.status='Rejected'});D.rfq.forEach(y=>{if(grp(y)==grp(f))y.status='Finished'});const p=D.pr.find(x=>x.id==f.pr);if(p)p.status='RFQ Sent'}}},
gr:{t:'Goods Receiving',pre:'GR',s:'Posting receipts updates Warehouse Inventory stock automatically',f:[['po','Purchase Order','ref','po'],['qty','Qty Received','num'],['date','Date Received','date'],['status','Status','sel',['Updated']]],
 after:r=>{const p=D.po.find(x=>x.id==r.po);if(!p)return;const s=D.items.find(x=>x.id==p.item);if(s)s.stock+=r.qty;p.status=recv(p.id)>=p.qty?'Completed':'Partial';if(p.status=='Completed')prDone(p)},
 chk:v=>{const p=D.po.find(x=>x.id==v.po);if(!(v.qty>0))return'Quantity must be more than zero.';if(p&&v.qty>p.qty-recv(p.id))return'Only '+(p.qty-recv(p.id))+' left to receive on '+p.no+'.'}},
inv:{t:'Purchase Invoice',pre:'INV',s:'Unpaid invoices post to Finance as payables',f:[['po','Purchase Order','ref','po'],['amount','Amount','num'],['due','Due Date','date'],['status','Status','sel',['Unpaid']]],
 a:[['Request Payment',r=>{if(confirm('Send a payment request to Finance for '+r.no+' – '+fmt(r.amount)+'?')){const n=ins('pq',{inv:r.id,amount:r.amount,date:today,status:'Pending'});M.pq.after(n);save();go();toast(n.no+' sent to Finance for approval.')}},r=>r.status=='Unpaid'&&!D.pq.some(q=>q.inv==r.id&&q.status!='Rejected')],['View Receipt',r=>viewRc(r.id),r=>r.status=='Paid'&&D.rc.some(c=>c.inv==r.id)]]}
};
M.suppliers.g='Add the companies you buy from. <b>Click a company name</b> to see its details and manage the prices it charges for each material.';
M.suppliers.x=[['Price List',r=>`<a class="lnk" onclick="nav('sup:${r.id}')">${new Set(D.pl.filter(x=>x.supplier==r.id).map(x=>x.item)).size} materials ›</a>`]];
M.items.g='List every material you buy. Stock goes up automatically when goods are received. These items appear in the Purchase Request dropdown.';
M.pl.g='Each company charges its own price for each material. Click <b>+ New</b> to add or update a price (the latest entry is used). These prices fill in automatically when you add a quotation.';
M.pr.g='Ask for the materials you need. Click <b>+ New</b>, pick the item and quantity. It is confirmed automatically once saved. Then click <b>Create RFQ</b> to ask a supplier for a price.';
M.rfq.g='A price request sent to a supplier. Click <b>+ New</b> and choose the material and quantity, or click <b>Create RFQ</b> on an approved Purchase Request to fill them in (the material then stays the same as the request). When the supplier replies, click <b>Add Quotation</b> and enter their price. Every price the suppliers sent shows in the <b>Supplier Prices Received</b> column, with the lowest marked.';
M.quo.g='The supplier\'s price offer. The material is always the one requested in the Purchase Request. Compare them, then click <b>Create PO</b> on the best one. The other quotations for the same request are rejected automatically.';
M.po.g='The order for the supplier. Click <b>Confirm</b> to send it to Finance (or <b>Cancel</b> to drop it). Finance then pays it (or cancels it) under <b>Finance → Payment Requests</b>. After payment, record the delivery under <b>Goods Receiving</b>. Finished orders can no longer be deleted.';
M.gr.g='Deliveries for orders that Finance has already paid. Orders waiting for delivery are listed at the top – click <b>Receive</b> and enter the quantity. Saving adds it to Warehouse Inventory automatically, and the order becomes <b>Completed</b> once everything is received.';
M.inv.g='The supplier\'s bill. It is created automatically when you Confirm a Purchase Order, and Finance pays it under <b>Payment Requests</b>. Once paid, the receipt appears here (<b>View Receipt</b>).';
const supOfInv=id=>{const i=D.inv.find(x=>x.id==id),p=i&&D.po.find(x=>x.id==i.po);return p?lbl('suppliers',p.supplier):'—'};
M.pq={t:'Payment Requests',pre:'PQ',s:'Confirmed purchase orders from Procurement – pay or cancel them',f:[['inv','Purchase Invoice','ref','inv'],['amount','Amount','num'],['date','Date Requested','date'],['status','Status','sel',['Pending','Approved','Rejected','Paid','Cancelled']]],
 x:[['Supplier',r=>esc(supOfInv(r.inv))],['Remarks',r=>r.reason?esc(r.reason):'—']],
 a:[['Pay',r=>openForm('rc',0,{pq:r.id,amount:r.amount}),r=>['Pending','Approved'].includes(r.status)],
 ['Cancel',r=>{if(confirm('Cancel '+r.no+'?\n\nThe invoice and its Purchase Order will be cancelled.')){r.status='Cancelled';const i=D.inv.find(x=>x.id==r.inv);if(i)i.status='Cancelled';const po=i&&D.po.find(x=>x.id==i.po);if(po&&po.status=='Pending')po.status='Cancelled';save();go();toast(r.no+' cancelled.')}},r=>['Pending','Approved'].includes(r.status)]],
 after:r=>{const i=D.inv.find(x=>x.id==r.inv);if(i&&i.status=='Unpaid')i.status='Payment Requested'}};
M.rc={t:'Payment Receipts',pre:'OR',s:'Official receipts issued by Finance for paid invoices',f:[['pq','Payment Request','ref','pq'],['amount','Amount Paid','num'],['method','Payment Method','sel',['Cash','Bank Transfer','GCash','Check']],['refno','Reference No.','text'],['date','Date Paid','date']],
 x:[['Supplier',r=>esc(supOfInv(r.inv))]],
 a:[['View / Print',r=>viewRc(r.inv,r.id)]],
 after:r=>{const q=D.pq.find(x=>x.id==r.pq);if(!q)return;r.inv=q.inv;q.status='Paid';const i=D.inv.find(x=>x.id==q.inv);if(i){i.status='Paid';const po=D.po.find(x=>x.id==i.po);if(po&&!['Cancelled','Completed'].includes(po.status))po.status=recv(po.id)>=po.qty?'Completed':recv(po.id)>0?'Partial':'Paid';if(po.status=='Completed')prDone(po)}}};
M.pq.g='Every Purchase Order confirmed by Procurement arrives here. Click <b>Pay</b> to enter the payment method and reference number – this issues a receipt and marks the invoice and order as Paid – or <b>Cancel</b> to cancel the order.';
M.rc.g='Official receipts issued when Finance pays an invoice. Click <b>View / Print</b> to open a printable copy. To pay an invoice, go to Payment Requests and click <b>Pay</b>.';

M.branches={t:'Branches',s:'The 25 branches that receive materials',f:[['name','Branch Name','text'],['status','Status','sel',['Active','Inactive']]],
 x:[['Materials Held',r=>r.wh?D.items.filter(i=>i.stock>0).length:D.bs.filter(x=>x.branch==r.id&&x.stock>0).length]]};
M.bs={t:'Branch Stock',s:'Stock and reorder level of each material in each branch',f:[['branch','Branch','ref','branches'],['item','Material','ref','items'],['stock','Stock on Hand','num'],['reorder','Reorder Level','num']],
 x:[['Status',r=>r.stock<=r.reorder?'<span class="pill r1">Low Stock</span>':'<span class="pill g1">OK</span>']]};
M.dist={t:'Branch Distribution',pre:'DS',s:'Issue materials from the main warehouse to a branch',f:[['branch','Branch','ref','branches'],['item','Material','ref','items'],['qty','Quantity','num'],['date','Date Issued','date'],['status','Status','sel',['Issued']]],
 chk:v=>{const it=D.items.find(x=>x.id==v.item);if(!(v.qty>0))return'Quantity must be more than zero.';if(!it||it.stock<v.qty)return'Not enough stock in the main warehouse.\nAvailable: '+(it?it.stock:0)+' '+(it?it.unit:'')+'. Receive more goods first.'},
 after:r=>{const it=D.items.find(x=>x.id==r.item);if(it)it.stock-=r.qty;let b=D.bs.find(x=>x.branch==r.branch&&x.item==r.item);if(!b)b=ins('bs',{branch:r.branch,item:r.item,stock:0,reorder:(it&&it.reorder)||0});b.stock+=r.qty;}};
M.branches.g='The 25 branches plus the Main Warehouse. Each branch has its own stock of every material (see <b>Branch Stock</b>). Use the Branch filter on the other pages to see one branch at a time.';
M.bs.g='How much of each material every branch holds. Stock goes up automatically when you <b>Issue to Branch</b>. To change a stock or reorder level, click <b>+ New</b> and pick the same branch and material (it updates the existing row).';
/* one-per-step rules */
M.suppliers.chk=v=>{const n=String(v.name||'').trim();v.name=n;if(!n)return'Enter the supplier name.';if(D.suppliers.some(s=>String(s.name).trim().toLowerCase()==n.toLowerCase()))return'A supplier named "'+n+'" already exists.'};
M.rfq.chk=v=>{if(v.pr!=null&&D.rfq.some(x=>x.pr==v.pr))return'This purchase request already has an RFQ. Only one RFQ is allowed per request.'};
M.po.chk=v=>{if(v._quo==null)return;const q=D.quo.find(x=>x.id==v._quo),f=q&&D.rfq.find(x=>x.id==q.rfq);if(!f)return;const rf=D.rfq.filter(y=>grp(y)==grp(f)).map(y=>y.id),qs=D.quo.filter(x=>rf.includes(x.rfq)).map(x=>x.id);if(D.po.some(o=>qs.includes(o._quo)&&o.status!='Cancelled'))return'A purchase order already exists for this request. Only one PO is allowed.'};
M.inv.chk=v=>{if(D.inv.some(i=>i.po==v.po&&i.status!='Cancelled'))return'This purchase order already has an invoice. Only one invoice is allowed per order.'};
M.pq.chk=v=>{if(D.pq.some(q=>q.inv==v.inv&&!['Rejected','Cancelled'].includes(q.status)))return'This invoice already has a payment request.'};
M.dist.g='Send materials from the main warehouse to a branch. Saving reduces the Warehouse Inventory stock and adds to that branch stock.';
const gwait=()=>{const w=D.po.filter(p=>['Paid','Partial'].includes(p.status));return`<div class="card tw" style="margin-bottom:18px"><b>Awaiting Delivery (paid orders)</b><table><tr><th>Order No.</th><th>Supplier</th><th>Material</th><th>Ordered</th><th>Received</th><th>Remaining</th><th>Actions</th></tr>${w.map(p=>`<tr><td><b class="ordno">${esc(p.ord||'—')}</b></td><td>${esc(lbl('suppliers',p.supplier))}</td><td>${esc(lbl('items',p.item))}</td><td>${p.qty}</td><td>${recv(p.id)}</td><td>${p.qty-recv(p.id)}</td><td class="acts"><button class="btn s" onclick="openForm('gr',0,{po:${p.id},qty:${p.qty-recv(p.id)}})">Receive</button></td></tr>`).join('')||'<tr><td colspan=7>No paid orders are waiting for delivery.</td></tr>'}</table></div>`};
const NEXT={pr:'Request confirmed automatically. Next: click Create RFQ.',rfq:'Next: when the supplier replies, click Add Quotation.',quo:'Next: click Create PO on the best quotation.',po:'Next: click Confirm to send it to Finance for payment.',gr:'Warehouse Inventory updated.',inv:'Next: when ready to pay, click Request Payment.',pq:'Finance will review it under Finance → Payment Requests.',rc:'Order paid. Next: record the delivery under Goods Receiving.',suppliers:'',items:'',pl:'',branches:'',bs:'',dist:'Warehouse stock reduced and branch stock increased.'};
const STEPS=[['pr','Request'],['rfq','RFQ'],['quo','Quotation'],['po','Order'],['inv','Invoice & Payment'],['gr','Receive']];
const todo=t=>({pr:D.pr.filter(x=>['Pending','Confirmed'].includes(x.status)).length,rfq:D.rfq.filter(x=>x.status=='Sent').length,quo:D.quo.filter(x=>x.status=='Received').length,po:D.po.filter(x=>x.status=='Open').length,inv:D.pq.filter(x=>['Pending','Approved'].includes(x.status)).length,gr:D.po.filter(x=>['Paid','Partial'].includes(x.status)).length}[t]||0);
const flowBar=()=>`<div class="flow">${STEPS.map((x,i)=>`<div class="st ${x[0]==cur?'on':''}" onclick="nav('${x[0]}')"><b>${i+1}</b>${x[1]}${todo(x[0])?`<em title="Needs action">${todo(x[0])}</em>`:''}</div>`).join('')}</div>`;
const flow=()=>'';
const guide=t=>'';
let HL=null;
function nav(v){HL=null;cur=v;if(isProc(v)){pOpen=true;fOpen=iOpen=false}if(isFin(v)){fOpen=true;pOpen=iOpen=false}if(isInv(v)){iOpen=true;pOpen=fOpen=false}$('#q').value='';go()}
function toast(){}
const NAV=[['pdash','Dashboard'],['suppliers','Supplier Management'],['pr','Purchase Request'],['rfq','Request for Quotation'],['quo','Quotation'],['po','Purchase Order'],['inv','Purchase Invoice'],['gr','Goods Receiving'],['rec','Supplier Records']];
/* ---------- DATABASE (persistent, localStorage) ---------- */
let D;try{D=JSON.parse(localStorage.getItem(K))}catch(e){}
function save(){try{localStorage.setItem(K,JSON.stringify(D))}catch(e){}}
const ORDT=['pr','rfq','quo','po','inv','gr','pq','rc','dist'];
/* Order numbers are plain numbers (0001, 0002, ...). A number is issued once and never reused or shifted: D.seq.ord only goes up, so deleting an order leaves its number retired and the next new order takes the next number. */
function ordNew(){D.seq=D.seq||{};const mx=Math.max(D.seq.ord||0,...ORDT.flatMap(t=>(D[t]||[]).map(x=>+String(x.ord||'').replace(/\D/g,'')||0)));D.seq.ord=mx+1;return String(D.seq.ord).padStart(4,'0')}
function ordParent(t,r){const f=(a,id)=>(D[a]||[]).find(x=>x.id==id);const g={rfq:()=>f('pr',r.pr),quo:()=>f('rfq',r.rfq),po:()=>f('quo',r._quo),inv:()=>f('po',r.po),gr:()=>f('po',r.po),pq:()=>f('inv',r.inv),rc:()=>f('pq',r.pq)||f('inv',r.inv),dist:()=>f('pr',r.pr)}[t];const x=g&&g();return x&&x.ord}
const poTaken=(o,self)=>D.po.some(p=>p!==self&&p.ord==o);
const ordFor=(t,r)=>{const o=ordParent(t,r);if(o&&!(t=='po'&&poTaken(o,r)))return o;return t=='dist'&&!o?undefined:ordNew()};
function ins(t,r){D.seq[t]=Math.max(D.seq[t]||0,...D[t].map(x=>x.id||0))+1;r.id=D.seq[t];r.no=(M[t].pre||'')+String(D[t].length+1).padStart(4,'0');if(ORDT.includes(t)&&!r.ord){const o=ordFor(t,r);if(o)r.ord=o}D[t].push(r);return r}
function ordClose(){const nums=[...new Set(ORDT.flatMap(t=>(D[t]||[]).map(x=>x.ord).filter(Boolean)))].sort((a,b)=>a-b),map={};nums.forEach((o,i)=>map[o]=String(i+1).padStart(4,'0'));ORDT.forEach(t=>(D[t]||[]).forEach(x=>{if(x.ord)x.ord=map[x.ord]}));D.seq=D.seq||{};D.seq.ord=nums.length}
function ordStrip(){ORDT.forEach(t=>(D[t]||[]).forEach(x=>{if(x.ord)x.ord=String(x.ord).replace(/\D/g,'').padStart(4,'0')}))}
function renum(t){if(M[t].pre)D[t].forEach((x,i)=>x.no=M[t].pre+String(i+1).padStart(4,'0'))}
if(!D){D={ver:5,seq:{},suppliers:[],pr:[],rfq:[],quo:[],po:[],gr:[],inv:[],pq:[],rc:[],bs:[],dist:[],branches:[],opts:{},items:[]};
 [['Filtered Water','Filtered Water','liters',2000,500],['Empty Container 5G','Empty Container','pcs',120,30],['Filter Cartridge','Filter','pcs',5,10],['Bottle Cap','Caps','pcs',40,100],['Safety Seal','Seals','pcs',300,100],['Label','Label','pcs',80,100]].forEach(a=>ins('items',{name:a[0],cat:a[1],unit:a[2],stock:a[3],reorder:a[4]}));
 [['AquaPlast Corp.','Maria Cruz','0917-555-0101','sales@aquaplast.ph','Calamba, Laguna'],['PureFilter Trading','John Reyes','0918-555-0202','info@purefilter.ph','Silang, Cavite'],['ChemSource PH','Ana Lim','0920-555-0303','ana@chemsource.ph','Makati City']].forEach(a=>ins('suppliers',{name:a[0],contact:a[1],phone:a[2],email:a[3],address:a[4],status:'Active'}));
 ins('pr',{item:3,qty:50,dept:'Production',date:today,status:'Confirmed'});ins('pr',{item:4,qty:500,dept:'Production',date:today,status:'Pending'});
 ins('rfq',{pr:1,supplier:2,due:today,status:'Responded'});ins('quo',{rfq:1,supplier:2,item:3,qty:50,price:180,status:'Accepted'});
 ins('po',{supplier:2,item:3,qty:50,price:180,date:today,status:'Open'});ins('po',{supplier:1,item:2,qty:200,price:95,date:today,status:'Open'});
save()}
D.pq=D.pq||[];D.rc=D.rc||[];D.pr.forEach(p=>{if(p.status=='Approved'||p.status=='Pending')p.status='Confirmed';if(p.status=='Issued')p.status='Completed'});D.bs=D.bs||[];D.dist=D.dist||[];D.branches=D.branches||[];D.rfq.forEach(r=>{const p=D.pr.find(x=>x.id==r.pr);if(p&&r.branch==null)r.branch=p.branch});D.quo.forEach(q=>{const f=D.rfq.find(x=>x.id==q.rfq);if(f&&q.branch==null)q.branch=f.branch});D.po.forEach(p=>{const q=D.quo.find(x=>x.id==p._quo);if(q&&p.branch==null)p.branch=q.branch});D.opts=D.opts||{};delete D.opts['inv.status'];delete D.opts['po.status'];D.po.forEach(p=>{if(p.status=='Received'){const i=D.inv.find(x=>x.po==p.id);p.status=i&&i.status=='Paid'?'Paid':'Pending'}});D.items=D.items||[];if(!D.noWater){D.items=D.items.filter(i=>i.name!='Filtered Water');D.bs=D.bs.filter(b=>D.items.some(i=>i.id==b.item));if(D.opts['items.cat'])D.opts['items.cat']=[...new Set(D.opts['items.cat'].filter(c=>c!='Filtered Water').concat('Filtration Tank'))];D.noWater=1}if(!D.ver){D.po.forEach(p=>{if(p.status=='Paid'||p.status=='Pending')p.status='Completed'});D.ver=3}if(D.ver<4){D.po.forEach(p=>{if(p.status=='Accepted')p.status='Confirmed';if(p.status=='Rejected')p.status='Open';if(p.status=='Confirmed'&&!D.inv.some(i=>i.po==p.id)){const i=ins('inv',{po:p.id,amount:p.qty*p.price,due:today,status:'Payment Requested'});ins('pq',{inv:i.id,amount:i.amount,date:today,status:'Pending'})}});delete D.fo;D.ver=4}if(D.ver<5){D.po.forEach(p=>{if(p.status=='Confirmed')p.status='Pending'});D.ver=5}if(!D.prDone){D.pr.forEach(p=>{if(p.status=='Ordered')p.status=poFor(p).some(o=>o.status=='Completed')?'Completed':'RFQ Sent'});D.prDone=1}D.gr.forEach(g=>{if(g.status=='Posted')g.status='Updated'});delete D.opts['gr.status'];delete D.opts['rfq.status'];D.rfq.forEach(r=>{if(r.status=='Closed')r.status='Finished'});
{const seen=new Set(),used=new Set(D.po.map(p=>p._quo));D.quo=D.quo.filter(q=>{const k=[q.rfq,q.supplier,q.item,q.qty,q.price,q.status].join('|');if(seen.has(k)&&!used.has(q.id))return false;seen.add(k);return true})}
D.items.forEach(i=>{if(i.cat=='Caps & Seals')i.cat=/seal/i.test(i.name)?'Seals':'Caps'});if(D.opts['items.cat'])D.opts['items.cat']=[...new Set(D.opts['items.cat'].flatMap(c=>c=='Caps & Seals'?['Caps','Seals']:[c]))];D.pr.forEach(p=>{if(p.status=='Quoted')p.status='RFQ Sent'});D.rfq.forEach(r=>{const p=D.pr.find(x=>x.id==r.pr);if(p&&r.item==null){r.item=p.item;r.qty=p.qty}});
(()=>{const f=n=>D.items.find(x=>x.name==n),E=(n,c,st,ro)=>f(n)||ins('items',{name:n,cat:c,unit:'pcs',stock:st,reorder:ro});
 const a=f('Empty Container 5G');if(a)a.name='5-Gallon Round Container';const b=f('Bottle Cap');if(b)b.name='Round Container Cap';
 E('5-Gallon Round Container','Empty Container',150,30);E('5-Gallon Slim Container','Empty Container',100,30);E('Round Container Cap','Caps',200,100);E('Slim Container Small Cap','Caps',150,100);E('Slim Container Big Cap','Caps',150,100);E('Multi-Filtration Tank','Filtration Tank',10,3);
 if(!D.pl){D.pl=[];const S=n=>(D.suppliers.find(x=>x.name==n)||{}).id,P={
 'AquaPlast Corp.':{'5-Gallon Round Container':95,'5-Gallon Slim Container':130,'Round Container Cap':4.5,'Slim Container Small Cap':3.5,'Slim Container Big Cap':5,'Safety Seal':1.2,'Label':0.8,'Filter Cartridge':185},
 'PureFilter Trading':{'5-Gallon Round Container':98,'5-Gallon Slim Container':126,'Round Container Cap':4.2,'Slim Container Small Cap':3.8,'Slim Container Big Cap':5.5,'Safety Seal':1,'Label':0.9,'Filter Cartridge':180},
 'ChemSource PH':{'5-Gallon Round Container':92,'5-Gallon Slim Container':135,'Round Container Cap':4.8,'Slim Container Small Cap':3.2,'Slim Container Big Cap':4.6,'Safety Seal':1.4,'Label':0.7,'Filter Cartridge':172}};
 Object.entries(P).forEach(([sn,o])=>Object.entries(o).forEach(([n,pr])=>{const i=f(n);if(S(sn)&&i)ins('pl',{supplier:S(sn),item:i.id,price:pr})}))}})();
const BR=["Alaminos (San Pablo)", "Bagong Pook", "Barangay I-A", "Barangay I-B", "Barangay II-A", "Barangay II-B", "Barangay III-A", "Barangay III-B", "Barangay IV-A", "Barangay IV-B", "Barangay V-A", "Barangay V-B", "Barangay VI-A", "Barangay VI-B", "Barangay VII-A", "Barangay VII-B", "Bautista", "Concepcion", "Del Remedio", "Dolores", "San Antonio", "San Buenaventura", "San Crispin", "San Francisco", "San Gabriel"];if(!D.branches.length)BR.forEach(n=>ins('branches',{name:n,status:'Active'}));if(!D.branches.some(b=>b.wh))ins('branches',{name:'Main Warehouse',wh:1,status:'Active'});
if(!D.sampleBS){const L=D.branches.filter(b=>!b.wh),I=D.items.filter(i=>i.cat!='Filtered Water');L.forEach((b,bi)=>I.forEach((it,ii)=>{if(!D.bs.some(x=>x.branch==b.id&&x.item==it.id))ins('bs',{branch:b.id,item:it.id,stock:20+((bi*7+ii*13)%15)*10,reorder:it.reorder||0})}));D.sampleBS=1;save()}
if(!D.tankPL){const t=D.items.find(i=>i.name=='Multi-Filtration Tank');if(t){D.pl=D.pl||[];[['AquaPlast Corp.',8500],['PureFilter Trading',8500],['ChemSource PH',8500]].forEach(([n,p])=>{const sp=D.suppliers.find(x=>x.name==n);if(sp&&!D.pl.some(x=>x.supplier==sp.id&&x.item==t.id))ins('pl',{supplier:sp.id,item:t.id,price:p})});D.tankPL=1}}
if(!D.tankP2){const t=D.items.find(i=>i.name=='Multi-Filtration Tank');if(t){D.pl.forEach(p=>{if(p.item==t.id)p.price=8500});D.tankP2=1}}
if(!D.tankBS){const t=D.items.find(i=>i.name=='Multi-Filtration Tank');if(t){D.branches.filter(b=>!b.wh).forEach((b,bi)=>{if(!D.bs.some(x=>x.branch==b.id&&x.item==t.id))ins('bs',{branch:b.id,item:t.id,stock:2+(bi*3)%6,reorder:2})});D.tankBS=1;save()}}
D.inv.forEach(i=>{if(i.status=='Paid'&&!D.rc.some(c=>c.inv==i.id)){const q=D.pq.find(x=>x.inv==i.id);ins('rc',{pq:q?q.id:null,inv:i.id,amount:i.amount,method:'Not recorded',refno:'—',date:i.due||today})}});
ORDT.forEach(t=>D[t].forEach(r=>{if(!r.ord){const o=ordFor(t,r);if(o)r.ord=o}}));
{const seenO=new Set();D.po.forEach(p=>{if(seenO.has(p.ord)){p.ord=ordNew();D.inv.filter(i=>i.po==p.id).forEach(i=>{i.ord=p.ord;D.pq.filter(q=>q.inv==i.id).forEach(q=>{q.ord=p.ord;D.rc.filter(c=>c.pq==q.id||c.inv==i.id).forEach(c=>c.ord=p.ord)})});D.gr.filter(g=>g.po==p.id).forEach(g=>g.ord=p.ord)}seenO.add(p.ord)})}
ordStrip();if(!D.ordFixed){ordClose();D.ordFixed=1}['pr','rfq','quo','po','gr','inv','pq','rc','dist'].forEach(renum);save();
const isWh=id=>!!(D.branches.find(x=>x.id==id)||{}).wh;
const brOf=(t,r)=>t=='gr'||t=='inv'?(D.po.find(x=>x.id==r.po)||{}).branch:r.branch;
const issued=id=>D.dist.filter(g=>g.pr==id).reduce((a,g)=>a+g.qty,0);
const recv=id=>D.gr.filter(g=>g.po==id).reduce((a,g)=>a+g.qty,0);
const lbl=(t,id)=>{const r=D[t].find(x=>x.id==id);return r?(r.name||r.no+(r.item?' · '+lbl('items',r.item):r.inv?' · '+lbl('inv',r.inv):'')):'—'};
const tot=r=>r.qty*r.price;
['pr','rfq','quo','po','gr','inv','pq','dist'].forEach(t=>M[t].nostat=1);ORDT.forEach(t=>M[t].ord=1);
/* ---------- UI ---------- */
let cur='dash',pOpen=false,fOpen=false,iOpen=false;const $=s=>document.querySelector(s);
const PROC=new Set(NAV.map(n=>n[0])),isProc=v=>PROC.has(v)||v.startsWith('sup:');
const FNAV=[['pq','Payment Requests'],['rc','Payment Receipts']],isFin=v=>FNAV.some(n=>n[0]==v);
const INAV=[['items','Warehouse Inventory'],['branches','Branches'],['bs','Branch Stock'],['dist','Branch Distribution']],isInv=v=>INAV.some(n=>n[0]==v);
const MODS={inventory:'Inventory',production:'Production',sales:'Sales & CRM',finance:'Finance',hr:'HR & Payroll',audit:'Audit Trail'};
const soon=k=>head(MODS[k]||'Module','This module is not part of the Procurement system yet')+`<div class="card soon"><h3>${esc(MODS[k]||'Module')}</h3><p>This section is coming soon.</p></div>`;
$('#nav').innerHTML=NAV.map(n=>`<a data-v="${n[0]}">${n[1]}</a>`).join('');
$('#inav').innerHTML=INAV.map(n=>`<a data-v="${n[0]}">${n[1]}</a>`).join('');
$('#fnav').innerHTML=FNAV.map(n=>`<a data-v="${n[0]}">${n[1]}</a>`).join('');
document.querySelectorAll('aside a').forEach(a=>a.onclick=()=>{const v=a.dataset.v;if(v=='proc'){pOpen=!pOpen;fOpen=iOpen=false;if(pOpen&&!isProc(cur))cur='pdash'}else if(v=='fin'){fOpen=!fOpen;pOpen=iOpen=false;if(fOpen&&!isFin(cur))cur='pq'}else if(v=='invt'){iOpen=!iOpen;pOpen=fOpen=false;if(iOpen&&!isInv(cur))cur='items'}else{cur=v;pOpen=isProc(v);fOpen=isFin(v);iOpen=isInv(v)}$('#q').value='';go()});
$('#q').oninput=go;$('#qx').onclick=()=>{$('#q').value='';go()};try{if(localStorage.getItem('aqua_theme')=='dark')document.body.classList.add('dark')}catch(e){}
$('#th').onclick=()=>{const d=document.body.classList.toggle('dark');try{localStorage.setItem('aqua_theme',d?'dark':'light')}catch(e){}};
const PRC={Pending:'o1',Confirmed:'b1','RFQ Sent':'p1',Completed:'g1',Issued:'t1',Rejected:'r1'};
const STC={suppliers:{Active:'g1',Inactive:'y1'},branches:{Active:'g1',Inactive:'y1'},
pr:{Pending:'o1',Confirmed:'b1','RFQ Sent':'p1',Completed:'g1',Rejected:'r1'},
rfq:{Sent:'b1',Responded:'a1',Finished:'g1'},
quo:{Received:'b1',Accepted:'g1',Rejected:'r1'},
po:{Open:'b1',Pending:'p1',Paid:'a1',Partial:'o1',Completed:'g1',Cancelled:'y1'},
inv:{Unpaid:'r1','Payment Requested':'o1',Paid:'g1',Cancelled:'y1'},
pq:{Pending:'o1',Approved:'b1',Rejected:'r1',Paid:'g1',Cancelled:'y1'},
gr:{Updated:'g1'},dist:{Issued:'t1'}};
const badge=(v,t)=>`<span class="pill ${((STC[t]||{})[v])||'y1'}">${esc(v)}</span>`;
const head=(t,s,btn='')=>`<div class="top"><div>${isProc(cur)||String(cur).startsWith('sup:')?'<div class="bc">Procurement</div>':isFin(cur)?'<div class="bc">Finance</div>':isInv(cur)?'<div class="bc">Inventory</div>':''}<h1>${t}</h1><div class="sub">${s}</div></div>${btn}</div>`;
function go(){if(!canView(cur))cur='pdash';setTimeout(()=>{const e=document.getElementById('hlrow');if(e){e.scrollIntoView({block:'center',behavior:'smooth'});setTimeout(()=>{HL=null;e.classList.remove('hl')},4000)}},60);document.querySelectorAll('aside a').forEach(a=>a.classList.toggle('on',a.dataset.v=='proc'?pOpen:a.dataset.v=='fin'?fOpen:a.dataset.v=='invt'?iOpen:a.dataset.v==(cur.startsWith('sup:')?'suppliers':cur)));
 $('#nav').classList.toggle('open',pOpen);$('#fnav').classList.toggle('open',fOpen);$('#inav').classList.toggle('open',iOpen);
 $('#pg').innerHTML=cur=='dash'?'':cur=='pdash'?dash():cur=='rep'?rep():cur.startsWith('mod:')?soon(cur.slice(4)):cur=='rec'?rec():cur.startsWith('sup:')?supPage(+cur.slice(4)):list(cur)}
function kpiBar(t){const N=(a,s)=>a.filter(x=>s.includes(x.status)).length,S=(a,f)=>a.reduce((c,x)=>c+(f(x)||0),0),po=D.po,live=po.filter(p=>p.status!='Cancelled');
const K={suppliers:[['Total Suppliers',D.suppliers.length],['Active Suppliers',N(D.suppliers,['Active'])],['Open POs',N(po,['Open','Pending','Paid','Partial'])],['Spend (POs)',fmt(S(live,tot))]],
items:[['Total Items',D.items.length],['Low Stock',D.items.filter(i=>i.stock<i.reorder).length],['Units on Hand',S(D.items,i=>i.stock)],['Categories',new Set(D.items.map(i=>i.cat)).size]],
branches:[['Total Branches',D.branches.length],['Active',N(D.branches,['Active'])],['Inactive',D.branches.length-N(D.branches,['Active'])]],
pr:[['Total Requests',D.pr.length],['Pending',N(D.pr,['Pending','RFQ Sent'])],['Completed',N(D.pr,['Completed'])],['Issued',N(D.pr,['Issued'])]],
rfq:[['Total RFQs',D.rfq.length],['Sent',N(D.rfq,['Sent'])],['Responded',N(D.rfq,['Responded'])],['Finished',N(D.rfq,['Finished'])]],
quo:[['Total Quotations',D.quo.length],['Received',N(D.quo,['Received'])],['Accepted',N(D.quo,['Accepted'])],['Rejected',N(D.quo,['Rejected'])]],
po:[['Pending',N(po,['Pending'])],['Paid',N(po,['Paid'])],['Completed',N(po,['Completed'])],['Total Value',fmt(S(live,tot))]],
inv:[['Invoices',D.inv.length],['Unpaid',N(D.inv,['Unpaid','Payment Requested'])],['Paid',N(D.inv,['Paid'])],['Amount Due',fmt(S(D.inv.filter(i=>['Unpaid','Payment Requested'].includes(i.status)),i=>i.amount))]],
pq:[['Pending',N(D.pq,['Pending','Approved'])],['Paid',N(D.pq,['Paid'])],['Cancelled',N(D.pq,['Cancelled'])],['Amount Due',fmt(S(D.pq.filter(q=>['Pending','Approved'].includes(q.status)),q=>q.amount))]],
rc:[['Receipts',D.rc.length],['Total Paid',fmt(S(D.rc,r=>r.amount))]],
gr:[['Receipts',D.gr.length],['Units Received',S(D.gr,g=>g.qty)],['Awaiting Delivery',N(po,['Paid','Partial'])],['Completed POs',N(po,['Completed'])]],
dist:[['Distributions',D.dist.length],['Units Issued',S(D.dist,x=>x.qty)],['Branches Served',new Set(D.dist.map(x=>x.branch)).size]],
bs:[['Stock Rows',D.bs.length],['Low Stock',D.bs.filter(b=>b.stock<b.reorder).length],['Units on Hand',S(D.bs,b=>b.stock)]]}[t];
return K?`<div class="kpis">${K.map(([l,v])=>`<div class="kpi"><div><i class="ki"></i>${l}</div><b>${v}</b></div>`).join('')}</div>`:''}
const NONO=['pr','rfq','quo','po','inv','gr'];
function list(t){const m=M[t],q=$('#q').value.toLowerCase(),hasB=m.f.some(f=>f[0]=='branch');
 const rows=D[t].filter(r=>(t!='bs'||!isWh(r.branch))&&(!BF||!hasB||brOf(t,r)==BF)&&(!q||JSON.stringify(r).toLowerCase().includes(q)||m.f.some(f=>f[2]=='ref'&&lbl(f[3],r[f[0]]).toLowerCase().includes(q))));
 if(NONO.includes(t))rows.sort((a,b)=>(+a.ord||0)-(+b.ord||0)||a.id-b.id);
 let h=(STEPS.some(x=>x[0]==t)?flow():'')+guide(t)+head(m.t,m.s,(m.nonew||!canAdd(t)?'':`<button class="btn new" onclick="openForm('${t}')">Add New +</button>`)+(t=='po'?` <button class="btn" onclick="exportOrders()">Export to Excel</button>`:''))+kpiBar(t)+(hasB?bfSel(t):'')+(t=='gr'?gwait():'')+`<div class="card tw"><table><tr>${m.ord?'<th>Order No.</th>':''}${m.pre&&!NONO.includes(t)?'<th>No.</th>':''}${m.f.map(f=>`<th>${f[1]}</th>`).join('')}${m.tot?'<th>Total</th>':''}${(m.x||[]).map(x=>`<th>${x[0]}</th>`).join('')}${t=='items'?'<th>Status</th>':'<th>Actions</th>'}</tr>`;
 rows.forEach(r=>{h+=`<tr${m.ord&&r.ord&&r.ord==HL?' class="hl" id="hlrow"':''}>${m.ord?`<td><b class="ordno">${esc(r.ord||'—')}</b></td>`:''}${m.pre&&!NONO.includes(t)?`<td><b>${r.no}</b></td>`:''}${m.f.map(([k,,ty,o])=>`<td>${t=='suppliers'&&k=='name'?`<a class="lnk" onclick="nav('sup:${r.id}')">${esc(r[k])}</a>`:ty=='ref'?esc(lbl(o,r[k])):k=='status'?(t=='suppliers'?supSel(r):badge(r[k],t)):['price','amount'].includes(k)?fmt(r[k]):esc(r[k])}</td>`).join('')}${m.tot?`<td>${fmt(tot(r))}</td>`:''}${(m.x||[]).map(x=>`<td>${x[1](r)}</td>`).join('')}${t=='items'?`<td>${r.stock<=r.reorder?'<span class="pill r1">Low Stock</span>':'<span class="pill g1">In Stock</span>'}</td>`:`<td class="acts">${(m.a||[]).map((a,i)=>(a[2]&&!a[2](r))||!canAct(t,a[0])?'':`<button class="btn s" onclick="act('${t}',${D[t].indexOf(r)},${i})">${a[0]}</button>`).join('')}${(m.nodel&&m.nodel(r))||!isSuper()?'':`<button class="btn s r" title="Delete" aria-label="Delete" onclick="del('${t}',${D[t].indexOf(r)})"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/></svg></button>`}</td>`}</tr>`});
 return h+(rows.length?'':'<tr><td colspan=9>No records yet.</td></tr>')+'</table></div>'}
const supSel=r=>`<select class="pill stsel ${r.status=='Active'?'g1':'y1'}" title="Change supplier status" onchange="setSup(${r.id},this.value)">${['Active','Inactive'].map(v=>`<option ${r.status==v?'selected':''}>${v}</option>`).join('')}</select>`;
function setSup(id,v){const x=D.suppliers.find(y=>y.id==id);if(!x)return;x.status=v;save();go()}
const act=(t,ix,i)=>{if(!canAct(t,M[t].a[i][0]))return;M[t].a[i][1](D[t][ix])};
function del(t,ix){if(!isSuper())return;if(confirm('Delete this record?')){const x=D[t].splice(ix,1)[0];
 if(t=='pq'&&x.status!='Paid'){const i=D.inv.find(y=>y.id==x.inv);if(i&&i.status=='Payment Requested')i.status='Unpaid'}
 if(t=='rc'){const q=D.pq.find(y=>y.id==x.pq),i=D.inv.find(y=>y.id==x.inv);if(q)q.status='Pending';if(i){i.status='Payment Requested';const po=D.po.find(y=>y.id==i.po);if(po&&po.status=='Paid')po.status='Pending'}}
 if(t=='dist'){const it=D.items.find(y=>y.id==x.item),b=D.bs.find(y=>y.branch==x.branch&&y.item==x.item);if(it)it.stock+=x.qty;if(b)b.stock=Math.max(0,b.stock-x.qty);if(x.pr){const p=D.pr.find(y=>y.id==x.pr);if(p&&p.status=='Issued')p.status='Completed'}}
 renum(t);save();go()}}
function rows(t,k,o,r){let a=D[o];
 if(o=='branches'){a=[...a].sort((x,y)=>(y.wh?1:0)-(x.wh?1:0));if(['dist','bs'].includes(t))a=a.filter(x=>!x.wh)}
 if(o=='items'&&['pr','rfq','quo','po','pl','dist','bs'].includes(t))a=a.filter(x=>x.cat!='Filtered Water'||x.id==r[k]);
 if(t=='quo'&&k=='item'){const id=r.rfq??(D.rfq.find(x=>x.status!='Finished')||{}).id,f=D.rfq.find(x=>x.id==id);if(f)a=a.filter(x=>x.id==f.item)}
 if(t=='po'&&k=='item'&&LINK&&LINK._quo)a=a.filter(x=>x.id==r.item);
 if(t=='rfq'&&k=='item'&&LINK&&LINK._pr)a=a.filter(x=>x.id==r.item);
 if(t=='pl'&&k=='supplier'&&r.supplier)a=a.filter(x=>x.id==r.supplier);
 if(t=='quo'&&k=='rfq')a=a.filter(x=>x.status!='Finished'||x.id==r.rfq);
 if(t=='dist'&&LINK&&LINK._pr&&(k=='item'||k=='branch'))a=a.filter(x=>x.id==r[k]);
 if(t=='gr'&&k=='po')a=a.filter(x=>['Paid','Partial'].includes(x.status)||x.id==r.po);
 if(t=='rc'&&k=='pq')a=a.filter(x=>['Pending','Approved'].includes(x.status)||x.id==r.pq);if(t=='pq'&&k=='inv')a=a.filter(x=>x.status=='Unpaid'||x.id==r.inv);
 return a}
function poFor(p){const rf=D.rfq.filter(x=>x.pr==p.id).map(x=>x.id),qs=D.quo.filter(q=>rf.includes(q.rfq)).map(q=>q.id);return D.po.filter(o=>qs.includes(o._quo))}
function prDone(po){const q=D.quo.find(x=>x.id==po._quo),f=q&&D.rfq.find(x=>x.id==q.rfq),pr=f&&D.pr.find(x=>x.id==f.pr);if(pr&&pr.status!='Issued')pr.status='Completed'}
const grp=r=>r.pr??'r'+r.id;
const listed=(sup,item)=>{const a=(D.pl||[]).filter(x=>x.supplier==sup&&x.item==item);return a.length?a[a.length-1].price:undefined};
const ADD=['suppliers','items'],opts=(t,k,d)=>D.opts[t+'.'+k]||d;
function formVals(t){const f=new FormData($('#fm')),v={};M[t].f.forEach(([k,,ty,o])=>{const x=f.get(k);v[k]=ty=='num'||ty=='ref'?(x==='__new'?'':Number(x)):(k=='status'&&M[t].nostat&&x==null?opts(t,k,o)[0]:x)});return v}
function addOpt(sel,t,k,id){
 if(sel.value!='__new'&&t=='quo'&&(k=='rfq'||k=='supplier')){const v=formVals('quo');if(k=='rfq'){const f=D.rfq.find(x=>x.id==v.rfq);if(f){v.item=f.item;v.qty=f.qty;v.supplier=f.supplier}}const l=listed(v.supplier,v.item);if(l!==undefined)v.price=l;openForm(t,id,LINK,v);return}
 if(sel.value!='__new')return;const fd=M[t].f.find(f=>f[0]==k),v=formVals(t),n=(prompt('Enter new '+fd[1].toLowerCase()+':')||'').trim();
 if(!n)v[k]=id?D[t].find(x=>x.id==id)[k]:undefined;
 else if(fd[2]=='sel'){D.opts[t+'.'+k]=[...opts(t,k,fd[3]),n];v[k]=n;save()}
 else{const rt=fd[3],x=ins(rt,rt=='items'?{name:n,cat:opts('items','cat',M.items.f[1][3]).find(c=>true),unit:'pcs',stock:0,reorder:0}:{name:n,contact:'',phone:'',email:'',address:'',status:'Active'});v[k]=x.id;save()}
 openForm(t,id,LINK,v)}
let LINK=null,BF='';const bfSel=t=>`<div style="margin:0 0 12px"><label style="font-size:12px">Branch: </label><select onchange="BF=this.value;go()" style="padding:8px;border-radius:8px;border:1px solid var(--bd);background:var(--in);color:var(--tx)"><option value="">All branches</option>${[...D.branches].filter(b=>!(t=='bs'&&b.wh)).sort((x,y)=>(y.wh?1:0)-(x.wh?1:0)).map(b=>`<option value="${b.id}" ${BF==b.id?'selected':''}>${esc(b.name)}</option>`).join('')}</select></div>`;
function openForm(t,id,pre,draft){LINK=pre||null;const m=M[t],r=draft||(id?D[t].find(x=>x.id==id):Object.assign({},pre||{}));
  let h=`<h3 style="color:var(--pri)">${id?'Edit':'New'} ${m.t}</h3>`;
 m.f.forEach(([k,l,ty,o])=>{if(k=='status'&&m.nostat)return;h+=`<label>${l}</label>`;
  if(ty=='sel')h+=`<select name="${k}" onchange="addOpt(this,'${t}','${k}',${id||0})">${opts(t,k,o).map(v=>`<option ${r[k]==v?'selected':''}>${esc(v)}</option>`).join('')}<option value="__new">+ Add new option…</option></select>`;
  else if(ty=='ref')h+=`<select name="${k}" onchange="addOpt(this,'${t}','${k}',${id||0})">${rows(t,k,o,r).map(x=>`<option value="${x.id}" ${r[k]==x.id?'selected':''}>${esc(lbl(o,x.id))}</option>`).join('')}${ADD.includes(o)&&!(t=='quo'&&k=='item')&&!(t=='rfq'&&k=='item'&&LINK&&LINK._pr)&&!(t=='po'&&k=='item'&&LINK&&LINK._quo)&&t!='dist'&&t!='bs'?'<option value="__new">+ Add new…</option>':''}</select>`;
  else h+=`<input name="${k}" type="${ty=='num'?'number':ty}" step="any" required value="${esc(r[k]??(ty=='date'?today:''))}">`});
 $('#fm').innerHTML=h+`<div class="bt"><button type="button" class="btn g" onclick="$('#md').classList.remove('on')">Cancel</button><button class="btn">Save</button></div>`;
 $('#md').classList.add('on');
 $('#fm').onsubmit=e=>{e.preventDefault();let msg='';const v=formVals(t);if(LINK&&LINK._quo)v._quo=LINK._quo;if(t=='dist'&&LINK&&LINK._pr)v.pr=LINK._pr;if(t=='quo'){const f=D.rfq.find(x=>x.id==v.rfq);if(f){v.item=f.item}}if(t=='rfq'&&LINK&&LINK._pr){const p=D.pr.find(x=>x.id==LINK._pr);if(p){v.pr=p.id;v.item=p.item}}if(t=='inv'&&v.status=='Paid'&&!confirm('WARNING: Are you sure this invoice is PAID?\n\nOnce saved as Paid, this cannot be undone.'))return;
  if(!id&&m.chk){const er=m.chk(v);if(er){alert(er);return}}
  if(!id&&t=='bs'){const ex=D.bs.find(x=>x.branch==v.branch&&x.item==v.item);if(ex){Object.assign(ex,v);save();$('#md').classList.remove('on');cur=t;go();toast('Branch stock updated.');return}}
  if(!id&&t=='quo'){const ex=D.quo.find(x=>x.rfq==v.rfq&&x.supplier==v.supplier&&x.status=='Received');if(ex){Object.assign(ex,v);save();$('#md').classList.remove('on');cur=t;go();toast(ex.no+' updated – this supplier already had a quotation for this request.');return}}
  if(id){if(m.nostat)delete v.status;const rr=D[t].find(x=>x.id==id);Object.assign(rr,v);const o=ordParent(t,rr);if(o&&!(t=='po'&&poTaken(o,rr)))rr.ord=o}else{const n=ins(t,v);m.after&&m.after(n);msg=(m.pre?n.no:m.t)+' saved. '+NEXT[t]}
  save();$('#md').classList.remove('on');cur=t=='pl'?'sup:'+v.supplier:(t=='suppliers'&&cur=='rec'?'rec':t);go();toast(msg)}}
/* ---------- DASHBOARD / RECORDS / REPORTS ---------- */
const spendBy=()=>{const o={};D.po.filter(p=>!['Cancelled','Rejected'].includes(p.status)).forEach(p=>o[p.supplier]=(o[p.supplier]||0)+tot(p));return Object.entries(o).map(([k,v])=>[lbl('suppliers',k),v]).sort((a,b)=>b[1]-a[1])};
const payables=()=>D.inv.filter(i=>i.status!='Paid');
const recentBuys=()=>`<br><div class="card tw"><b>Recent Purchases</b><table><tr><th>Order No.</th><th>No.</th><th>Supplier</th><th>Material</th><th>Total</th><th>Status</th><th>Actions</th></tr>${D.po.slice(-5).reverse().map(p=>{const i=D.inv.find(x=>x.po==p.id&&x.status=='Paid');return`<tr><td><b class="ordno">${esc(p.ord||'—')}</b></td><td><b>${p.no}</b></td><td>${esc(lbl('suppliers',p.supplier))}</td><td>${esc(lbl('items',p.item))}</td><td>${fmt(tot(p))}</td><td>${badge(p.status,'po')}</td><td class="acts">${i&&D.rc.some(c=>c.inv==i.id)?`<button class="btn s" onclick="viewRc(${i.id})">View Receipt</button>`:''}</td></tr>`}).join('')||'<tr><td colspan=7>No purchases yet.</td></tr>'}</table></div>`;
function dash(){const sp=spendBy(),mx=Math.max(1,...sp.map(s=>s[1])),totSp=sp.reduce((a,s)=>a+s[1],0),op=D.po.filter(p=>['Open','Pending','Paid','Partial'].includes(p.status)).length,pend=D.pr.filter(p=>p.status=='Pending').length,low=D.items.filter(s=>s.stock<=s.reorder).length,pay=payables();
 const cnt=POS.map(s=>D.po.filter(p=>p.status==s).length),col=POCOL,T=cnt.reduce((a,b)=>a+b,0)||1;let a=0;
 const cg=cnt.map((c,i)=>{const s=a;a+=c/T*100;return`${col[i]} ${s}% ${a}%`}).join(',');
 return flow()+head('Procurement Dashboard','AquaTrack Water Refilling Station')+`<div class="cards">
 <div class="card"><div class="l">Total Purchases</div><div class="v">${fmt(totSp)}</div><span class="pill g1">${D.po.length} purchase orders</span></div>
 <div class="card"><div class="l">Open POs</div><div class="v">${op}</div><span class="pill b1">${pend} requests pending</span></div>
 <div class="card"><div class="l">Warehouse Alerts</div><div class="v">${low}</div><span class="pill o1">${low} at reorder level</span></div>
 <div class="card"><div class="l">Payables (Finance)</div><div class="v">${fmt(pay.reduce((a,i)=>a+i.amount,0))}</div><span class="pill r1">${pay.length} unpaid invoices</span></div></div>
 <div class="row"><div class="card"><b>Spend per Supplier</b><div class="bars">${sp.slice(0,6).map((s,i)=>`<div><i class="${i?'':'h'}" style="height:${Math.max(8,s[1]/mx*150)}px"></i>${esc(s[0].split(' ')[0])}</div>`).join('')||'No data'}</div></div>
 <div class="card"><b>Purchase Order Status Mix</b><br><br><div class="donut" style="background:conic-gradient(${cg})"><span><b style="font-size:20px;color:var(--pri)">${D.po.length}</b><br>Total POs</span></div>
 <div class="lg" style="margin-top:14px">${POS.map((s,i)=>`<div><i style="background:${col[i]}"></i>${s} ${Math.round(cnt[i]/T*100)}%</div>`).join('')}</div></div></div>`+recentBuys()}
function supPage(id){const s=D.suppliers.find(x=>x.id==id);if(!s){cur='suppliers';return list('suppliers')}
 const pl=D.pl.filter(x=>x.supplier==id).slice().reverse(),seen={};
 let h=`<a class="lnk back" onclick="nav('suppliers')">← Back to Supplier Management</a>`+head(esc(s.name),'Company details and price list',`<button class="btn" onclick="openForm('pl',0,{supplier:${id}})">+ Add Price</button>`)+
 `<div class="card tw" style="margin-bottom:18px"><table><tr><th>Contact</th><th>Phone</th><th>Email</th><th>Address</th><th>Status</th></tr><tr><td>${esc(s.contact)}</td><td>${esc(s.phone)}</td><td>${esc(s.email)}</td><td>${esc(s.address)}</td><td>${supSel(s)}</td></tr></table></div>`+
 `<div class="card tw"><b>Price List – materials ${esc(s.name)} sells</b><table><tr><th>Material</th><th>Category</th><th>Unit Price</th><th>Price Status</th><th>Actions</th></tr>`;
 pl.forEach(r=>{const it=D.items.find(x=>x.id==r.item)||{},isNew=!seen[r.item];seen[r.item]=1;h+=`<tr><td>${esc(it.name)}</td><td>${esc(it.cat)}</td><td><b>${fmt(r.price)}</b></td><td>${isNew?'<span class="pill g1">Current</span>':'<span class="pill y1">Old price</span>'}</td><td><button class="btn s r" title="Delete" aria-label="Delete" onclick="del('pl',${D.pl.indexOf(r)})"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/></svg></button></td></tr>`});
 return h+(pl.length?'':'<tr><td colspan=5>No prices yet. Click + Add Price.</td></tr>')+'</table></div>'}
function showOrds(id){const s=D.suppliers.find(x=>x.id==id);if(!s)return;
 const o=[...new Set(D.po.filter(x=>x.supplier==id&&x.ord).map(x=>x.ord))].sort((a,b)=>a-b);
 $('#fm').onsubmit=e=>e.preventDefault();
 $('#fm').innerHTML=`<h3 style="color:var(--pri)">Orders – ${esc(s.name)}</h3><p style="margin:0 0 10px"><small>Click an order number to open it in Purchase Invoice.</small></p><div class="ordlist">${o.map(x=>`<a class="lnk ordpick" onclick="openOrd('${esc(x)}')"><b class="ordno">${esc(x)}</b> ›</a>`).join('')||'No orders.'}</div><div class="bt"><button type="button" class="btn g" onclick="$('#md').classList.remove('on')">Close</button></div>`;
 $('#md').classList.add('on')}
function openOrd(o){$('#md').classList.remove('on');nav('inv');HL=o;go()}
function rec(){const q=$('#q').value.toLowerCase(),ords=s=>[...new Set(D.po.filter(x=>x.supplier==s.id&&x.ord).map(x=>x.ord))].sort((a,b)=>a-b);
 let h=head('Supplier Records','Purchase history and balances per supplier')+'<div class="card tw"><table><tr><th>Supplier</th><th>Contact</th><th>Status</th><th>Order No(s).</th><th>Total Purchased</th><th>Outstanding Payable</th><th>Last Order</th></tr>';
 const L=D.suppliers.filter(s=>!q||JSON.stringify(s).toLowerCase().includes(q)||ords(s).some(o=>o.toLowerCase().includes(q)));
 L.forEach(s=>{const p=D.po.filter(x=>x.supplier==s.id),ids=p.map(x=>x.id),out=D.inv.filter(i=>ids.includes(i.po)&&i.status!='Paid').reduce((a,i)=>a+i.amount,0),o=ords(s);
  h+=`<tr><td><b>${esc(s.name)}</b><br><small>${esc(s.email)}</small></td><td>${esc(s.contact)}<br><small>${esc(s.phone)}</small></td><td>${badge(s.status,'suppliers')}</td><td>${o.length?`<button class="btn s" onclick="showOrds(${s.id})">View Orders (${o.length})</button>`:'—'}</td><td>${fmt(p.reduce((a,x)=>a+tot(x),0))}</td><td>${fmt(out)}</td><td>${p.length?p[p.length-1].date:'—'}</td></tr>`});
 return h+(L.length?'':'<tr><td colspan=8>No suppliers found.</td></tr>')+'</table></div>'}
function rep(){const sp=spendBy(),mx=Math.max(1,...sp.map(s=>s[1]));
 return head('Purchase Reports','Spend, inventory and finance integration',`<span class="noprint"><button class="btn" onclick="exportOrders()">Export to Excel</button> <button class="btn g" onclick="print()">Print</button> <button class="btn g" onclick="bk()">Backup DB</button> <button class="btn g" onclick="$('#im').click()">Restore DB</button><input id="im" type="file" hidden accept=".json" onchange="rs(this)"></span>`)+
 `<div class="card tw"><b>Spend by Supplier</b><table>${sp.map(s=>`<tr><td width=200>${esc(s[0])}</td><td><div class="bar" style="width:${s[1]/mx*100}%"></div></td><td>${fmt(s[1])}</td></tr>`).join('')}</table></div><br>
 <div class="row" style="grid-template-columns:1fr 1fr"><div class="card tw"><b>Warehouse Inventory Stock (updated by Goods Receiving)</b><table><tr><th>Item</th><th>Category</th><th>Stock</th></tr>${D.items.map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.cat)}</td><td>${s.stock} ${esc(s.unit)} ${s.stock<=s.reorder?'<span class="pill o1">Reorder</span>':''}</td></tr>`).join('')}</table></div>
 <div class="card tw"><b>Finance Payables Ledger</b><table><tr><th>Order No.</th><th>Invoice</th><th>Supplier</th><th>Amount</th><th>Status</th></tr>${D.inv.map(i=>{const p=D.po.find(x=>x.id==i.po)||{};return`<tr><td><b class="ordno">${esc(i.ord||'—')}</b></td><td>${i.no}</td><td>${esc(lbl('suppliers',p.supplier))}</td><td>${fmt(i.amount)}</td><td>${badge(i.status,'inv')}</td></tr>`}).join('')}</table></div></div><br><div class="card tw"><b>Stock per Branch</b><table><tr><th>Branch</th><th>Materials</th><th>Total Units</th><th>Low Stock Items</th></tr>${D.branches.filter(b=>!b.wh).map(b=>{const r=D.bs.filter(x=>x.branch==b.id);return`<tr><td>${esc(b.name)}</td><td>${r.length}</td><td>${r.reduce((a,x)=>a+x.stock,0)}</td><td>${r.filter(x=>x.stock<=x.reorder).length||'—'}</td></tr>`}).join('')}</table></div>`}
/* ---------- OFFICIAL RECEIPT ---------- */
const _o=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'],_t=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
const _w=n=>n<20?_o[n]:n<100?_t[Math.floor(n/10)]+(n%10?'-'+_o[n%10]:''):_o[Math.floor(n/100)]+' Hundred'+(n%100?' '+_w(n%100):'');
const words=n=>{if(n==0)return'Zero';const o=[];for(const[v,l]of[[1e9,'Billion'],[1e6,'Million'],[1e3,'Thousand']])if(n>=v){o.push(words(Math.floor(n/v))+' '+l);n%=v}if(n>0)o.push(_w(n));return o.join(' ')};
const pesoWords=a=>{const tc=Math.round(Number(a||0)*100),p=Math.floor(tc/100),c=tc%100;return words(p)+(p==1?' Peso':' Pesos')+(c?' and '+String(c).padStart(2,'0')+'/100':'')+' Only'};
const vcode=s=>{let h=2166136261;for(const ch of s){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return 'AQ-'+h.toString(36).toUpperCase().padStart(7,'0').slice(-7)};
const DROP='M0-15C7-6 12-1 12 5a12 12 0 0 1-24 0c0-6 5-11 12-20z';
const sealSvg=d=>`<svg class="seal" viewBox="0 0 160 160" xmlns="http://www.w3.org/2000/svg"><defs><path id="sealT" d="M24,80A56,56 0 0 1 136,80"/><path id="sealB" d="M16,80A64,64 0 0 0 144,80"/></defs><g fill="none" stroke="#1b4f9c"><circle cx="80" cy="80" r="76" stroke-width="3"/><circle cx="80" cy="80" r="71.500" stroke-width=".9"/><circle cx="80" cy="80" r="51" stroke-width="1.400"/><circle cx="80" cy="80" r="47.500" stroke-width=".7"/></g><g fill="#1b4f9c" font-family="Arial,Helvetica,sans-serif" font-weight="700"><text font-size="10.500" letter-spacing=".6"><textPath href="#sealT" startOffset="50%" text-anchor="middle" textLength="140" lengthAdjust="spacing">WATER REFILLING STATION</textPath></text><text font-size="10.500" letter-spacing=".6"><textPath href="#sealB" startOffset="50%" text-anchor="middle" textLength="160" lengthAdjust="spacing">AQUATRACK · OFFICIAL SEAL</textPath></text><text x="16" y="84" font-size="12" text-anchor="middle">★</text><text x="144" y="84" font-size="12" text-anchor="middle">★</text><path transform="translate(80 54) scale(.95)" d="${DROP}"/><text x="80" y="91" font-size="21" text-anchor="middle" letter-spacing="2.500">PAID</text><text x="80" y="107" font-size="9" text-anchor="middle" letter-spacing=".5">${esc(d)}</text></g></svg>`;
function rcHtml(c){const i=D.inv.find(x=>x.id==c.inv)||{},p=D.po.find(x=>x.id==i.po)||{},ord=c.ord||i.ord||'—',sup=supOfInv(c.inv),mat=p.item?lbl('items',p.item):'—',
 ms=opts('rc','method',M.rc.f[2][3]),code=vcode([c.no,ord,c.amount,c.date,c.refno,sup].join('|'));
 const ck=ms.map(m=>`<span class="ck${m==c.method?' on':''}"><i></i>${esc(m)}</span>`).join('');
 return`<div class="or"><div class="or-in">
 <svg class="or-wm" viewBox="-20 -20 40 40"><path d="${DROP}" fill="#1b4f9c"/></svg>
 <div class="or-hd"><div class="or-logo"><svg viewBox="-16 -18 32 36"><path d="${DROP}" fill="#fff"/><path d="M-8 6c3-3 5 3 8 0s5 3 8 0" fill="none" stroke="#16427f" stroke-width="1.800" stroke-linecap="round"/></svg></div>
 <div class="or-bn"><b>AquaTrack</b><span>WATER REFILLING STATION</span></div>
 <div class="or-ti"><h2>OFFICIAL RECEIPT</h2><span>Payment to Supplier</span></div>
 <div class="or-no"><small>NO.</small><b>${esc(c.no)}</b></div></div>
 <div class="or-r2"><div class="or-row"><label>DATE</label><span class="fill">${esc(c.date)}</span></div><div class="or-row"><label>ORDER NO.</label><span class="fill">${esc(ord)}</span></div></div>
 <div class="or-row"><label>PAID TO</label><span class="fill">${esc(sup)}</span></div>
 <div class="or-row"><label>THE SUM OF</label><span class="fill sm">${esc(pesoWords(c.amount))}</span></div>
 <div class="or-mid"><table class="or-tb"><tr><th colspan="2">IN PAYMENT OF</th></tr><tr><td class="k">Invoice No.</td><td>${esc(i.no||'—')}</td></tr><tr><td class="k">Purchase Order</td><td>${esc(p.no||'—')}</td></tr><tr><td class="k">Material</td><td>${esc(mat)}</td></tr></table>
 <div class="or-amt"><small>AMOUNT PAID</small><b>${fmt(c.amount)}</b></div></div>
 <div class="or-row pay"><label>PAID BY</label><span class="cks">${ck}</span><label class="rf">REF. NO.</label><span class="fill rfv">${esc(c.refno||'—')}</span></div>
 <div class="or-ft">${sealSvg(c.date)}<div class="sig"><div class="sl"></div><b>AUTHORIZED SIGNATURE</b><span>Finance Department</span></div></div>
 <div class="or-note"><span>Valid only when stamped with the official AquaTrack seal and signed by the Finance Department.</span><span>Validation Code: <b>${code}</b></span></div>
 </div></div>`}
let _ttl=document.title;
function viewRc(iid,rid){const c=rid!=null?D.rc.find(x=>x.id==rid):[...D.rc].reverse().find(x=>x.inv==iid);if(!c)return;
 $('#rcpt').innerHTML=rcHtml(c);$('#rm').dataset.no=c.no;$('#rm').classList.add('on')}
function closeRc(){$('#rm').classList.remove('on')}
addEventListener('beforeprint',()=>{const r=$('#rm');if(r&&r.classList.contains('on')){_ttl=document.title;document.title='Official Receipt '+(r.dataset.no||'')}});
addEventListener('afterprint',()=>{document.title=_ttl});

/* ---------- EXCEL EXPORT (orders summary per month & year; no library needed) ---------- */
const MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
const xe=s=>String(s??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const xc=i=>{let s='';i++;while(i>0){const m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=(i-m-1)/26}return s};
const xser=d=>{const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(d||'');return m?Math.round((Date.UTC(+m[1],+m[2]-1,+m[3])-Date.UTC(1899,11,30))/864e5):null};
const crcT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
const crc32=b=>{let c=-1;for(let i=0;i<b.length;i++)c=crcT[(c^b[i])&255]^(c>>>8);return(c^-1)>>>0};
function zipStore(files){const enc=new TextEncoder(),out=[],cen=[];let off=0;const u16=v=>[v&255,v>>8&255],u32=v=>[v&255,v>>8&255,v>>16&255,v>>>24&255];
 files.forEach(f=>{const nm=enc.encode(f.name),d=enc.encode(f.data),crc=crc32(d);
  const lh=Uint8Array.from([0x50,0x4b,3,4,...u16(20),...u16(0),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(d.length),...u32(d.length),...u16(nm.length),...u16(0)]);
  out.push(lh,nm,d);
  cen.push(Uint8Array.from([0x50,0x4b,1,2,...u16(20),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(d.length),...u32(d.length),...u16(nm.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(off)]),nm);
  off+=lh.length+nm.length+d.length});
 const cs=cen.reduce((a,b)=>a+b.length,0);
 return new Blob([...out,...cen,Uint8Array.from([0x50,0x4b,5,6,0,0,0,0,...u16(files.length),...u16(files.length),...u32(cs),...u32(off),...u16(0)])],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})}
/* style ids */
const XS={title:1,sub:2,note:3,head:4,txt:5,ctr:6,date:7,int:8,money:9,tlab:10,tint:11,tmoney:12,tblank:13,bold:14,blab:15,sec:16};
const XSTYLES=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="3"><numFmt numFmtId="164" formatCode="&quot;₱&quot;#,##0.00"/><numFmt numFmtId="165" formatCode="#,##0"/><numFmt numFmtId="166" formatCode="mmm\\ dd\\,\\ yyyy"/></numFmts>
<fonts count="7"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/></font><font><b/><sz val="16"/><color rgb="FF16427F"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><i/><sz val="9"/><color rgb="FF666666"/><name val="Arial"/></font><font><b/><sz val="12"/><color rgb="FF1F6FB5"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FF16427F"/><name val="Arial"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F6FB5"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCE9F5"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="3"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFA6B8CC"/></left><right style="thin"><color rgb="FFA6B8CC"/></right><top style="thin"><color rgb="FFA6B8CC"/></top><bottom style="thin"><color rgb="FFA6B8CC"/></bottom><diagonal/></border><border><left style="thin"><color rgb="FFA6B8CC"/></left><right style="thin"><color rgb="FFA6B8CC"/></right><top style="medium"><color rgb="FF16427F"/></top><bottom style="double"><color rgb="FF16427F"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="17"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="3" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="166" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="165" fontId="1" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="164" fontId="1" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right"/></xf>
<xf numFmtId="0" fontId="6" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
function xSheet(o){const mc=Math.max(...o.rows.map(r=>r.c.length)),H='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
 let x=H+'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'+`<dimension ref="A1:${xc(mc-1)}${o.rows.length}"/>`+
 `<sheetViews><sheetView showGridLines="0" workbookViewId="0"${o.first?' tabSelected="1"':''}>${o.freeze?`<pane ySplit="${o.freeze}" topLeftCell="A${o.freeze+1}" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A${o.freeze+1}" sqref="A${o.freeze+1}"/>`:''}</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>`+
 `<cols>${o.cols.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>`;
 o.rows.forEach((r,ri)=>{x+=`<row r="${ri+1}"${r.h?` ht="${r.h}" customHeight="1"`:''}>`;
  r.c.forEach((c,ci)=>{if(c==null)return;const ref=xc(ci)+(ri+1),s=c.s?` s="${c.s}"`:'';
   if(c.f!==undefined)x+=`<c r="${ref}"${s}><f>${xe(c.f)}</f><v>${c.v}</v></c>`;
   else if(typeof c.v=='number')x+=`<c r="${ref}"${s}><v>${c.v}</v></c>`;
   else if(c.v===''||c.v==null)x+=`<c r="${ref}"${s}/>`;
   else x+=`<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${xe(c.v)}</t></is></c>`});
  x+='</row>'});
 x+='</sheetData>'+(o.merges&&o.merges.length?`<mergeCells count="${o.merges.length}">${o.merges.map(m=>`<mergeCell ref="${m}"/>`).join('')}</mergeCells>`:'')+
 '<printOptions horizontalCentered="1"/><pageMargins left="0.4" right="0.4" top="0.6" bottom="0.7" header="0.3" footer="0.3"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>'+
 `<headerFooter><oddFooter>${xe('&LAquaTrack Water Refilling Station&CPage &P of &N&RPrinted &D')}</oddFooter></headerFooter></worksheet>`;
 return x}
/* collect orders grouped by year-month of the order date */
function xlGroups(){const g={};D.po.forEach(p=>{const d=(p.date||today).slice(0,10),k=d.slice(0,7);const i=D.inv.filter(x=>x.po==p.id&&x.status!='Cancelled').pop()||D.inv.filter(x=>x.po==p.id).pop(),c=i&&D.rc.filter(x=>x.inv==i.id).pop();
  (g[k]=g[k]||[]).push({ord:p.ord||'',date:d,po:p.no,sup:lbl('suppliers',p.supplier),item:lbl('items',p.item),qty:+p.qty||0,price:+p.price||0,total:tot(p),st:p.status,inv:i?i.no:'',pay:i?(i.status=='Payment Requested'?'Pending Payment':i.status):'Not invoiced',rc:c?c.no:'',paid:c?c.date:'',meth:c?c.method:'',ref:c?c.refno:''})});
 Object.values(g).forEach(a=>a.sort((x,y)=>(x.date<y.date?-1:x.date>y.date?1:0)||String(x.ord).localeCompare(String(y.ord))));
 return Object.keys(g).sort().map(k=>({k,y:+k.slice(0,4),m:+k.slice(5,7),rows:g[k]}))}
const xlLive=r=>r.st!='Cancelled';
function xlBook(sel,mode){const genOn=new Date().toISOString().slice(0,10),H='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
 all=sel.flatMap(g=>g.rows),n=all.length,f=6,e=5+n,T=e+1,NC=16,
 y0=Math.min(...sel.map(g=>g.y)),y1=Math.max(...sel.map(g=>g.y)),single=sel.length==1,
 period=single?MONTHS[sel[0].m-1]+' '+sel[0].y:y0==y1?String(y0):y0+' – '+y1;
 const live=all.filter(xlLive),sum=a=>a.reduce((s,r)=>s+r.total,0);
 /* ---- Sheet 1: every order, one by one ---- */
 const R=[],blank=()=>Array(NC).fill(null),row=(h,c)=>R.push({h,c});
 row(26,[{v:'AquaTrack Water Refilling Station',s:XS.title}]);row(18,[{v:'List of Purchase Orders – '+period,s:XS.sub}]);row(14,[{v:'Generated '+genOn+'. Every order is listed below; cancelled orders are shown but not counted in the totals.',s:XS.note}]);row(8,[]);
 row(32,['No.','Order No.','Order Date','PO No.','Supplier','Material','Qty','Unit Price','Total Amount','PO Status','Invoice No.','Payment Status','Receipt No.','Date Paid','Payment Method','Reference No.'].map(v=>({v,s:XS.head})));
 all.forEach((r,i)=>{const c=blank();c[0]={v:i+1,s:XS.ctr};c[1]={v:r.ord,s:XS.ctr};c[2]={v:xser(r.date),s:XS.date};c[3]={v:r.po,s:XS.ctr};c[4]={v:r.sup,s:XS.txt};c[5]={v:r.item,s:XS.txt};c[6]={v:r.qty,s:XS.int};c[7]={v:r.price,s:XS.money};c[8]={f:`G${f+i}*H${f+i}`,v:r.total,s:XS.money};c[9]={v:r.st,s:XS.ctr};c[10]={v:r.inv,s:XS.ctr};c[11]={v:r.pay,s:XS.ctr};c[12]={v:r.rc,s:XS.ctr};c[13]=r.paid?{v:xser(r.paid),s:XS.date}:{v:'',s:XS.ctr};c[14]={v:r.meth,s:XS.ctr};c[15]={v:r.ref,s:XS.ctr};row(0,c)});
 const tc=Array(NC).fill(null).map(()=>({v:'',s:XS.tblank}));tc[0]={v:'TOTAL (excluding cancelled orders)',s:XS.tlab};
 tc[6]={f:`SUMIF(J${f}:J${e},"<>Cancelled",G${f}:G${e})`,v:live.reduce((s,r)=>s+r.qty,0),s:XS.tint};tc[8]={f:`SUMIF(J${f}:J${e},"<>Cancelled",I${f}:I${e})`,v:sum(live),s:XS.tmoney};row(20,tc);
 const orders={rows:R,cols:[5,9,13,9,24,26,7,13,15,13,11,17,10,13,15,14],freeze:5,first:1,merges:['A1:P1','A2:P2','A3:P3',`A${T}:F${T}`]};
 /* ---- Sheet 2: summary per month or per year (formulas read the Orders sheet) ---- */
 const O="Orders!",rg=c=>`${O}$${c}$${f}:$${c}$${e}`,dt=(y,m)=>`DATE(${y},${m},1)`,
  crit=(y1_,m1,y2,m2)=>`${rg('C')},">="&${dt(y1_,m1)},${rg('C')},"<"&${dt(y2,m2)},${rg('J')},"<>Cancelled"`;
 const S=[],srow=(h,c)=>S.push({h,c}),byM=mode!='year';
 srow(26,[{v:'AquaTrack Water Refilling Station',s:XS.title}]);srow(18,[{v:'Purchase Orders Summary – per '+(byM?'Month':'Year')+' ('+period+')',s:XS.sub}]);srow(14,[{v:'Generated '+genOn+'. Figures are calculated from the Orders sheet and exclude cancelled orders.',s:XS.note}]);srow(8,[]);
 const heads=byM?['Year','Month','No. of Orders','Total Qty','Total Amount','Paid','Unpaid Balance']:['Year','No. of Orders','Total Qty','Total Amount','Paid','Unpaid Balance'];
 srow(32,heads.map(v=>({v,s:XS.head})));
 const units=byM?sel.map(g=>({y:g.y,m:g.m,lab:MONTHS[g.m-1],rows:g.rows})):[...new Set(sel.map(g=>g.y))].map(y=>({y,rows:sel.filter(g=>g.y==y).flatMap(g=>g.rows)}));
 const base=6;
 units.forEach((u,i)=>{const L=u.rows.filter(xlLive),r=base+i,tot_=sum(L),pd=sum(L.filter(x=>x.pay=='Paid')),qt=L.reduce((s,x)=>s+x.qty,0),
   cr=byM?(u.m==12?crit(u.y,u.m,u.y+1,1):crit(u.y,u.m,u.y,u.m+1)):crit(u.y,1,u.y+1,1),
   cnt={f:`COUNTIFS(${cr})`,v:L.length,s:XS.int},qty={f:`SUMIFS(${rg('G')},${cr})`,v:qt,s:XS.int},amt={f:`SUMIFS(${rg('I')},${cr})`,v:tot_,s:XS.money},
   paid={f:`SUMIFS(${rg('I')},${cr},${rg('L')},"Paid")`,v:pd,s:XS.money};
   const o=byM?4:3;
   srow(0,[{v:u.y,s:XS.ctr},...(byM?[{v:u.lab,s:XS.ctr}]:[]),cnt,qty,amt,paid,{f:`${xc(o+1)}${r}-${xc(o+2)}${r}`,v:tot_-pd,s:XS.money}])});
 const a=base,b=base+units.length-1,k=byM?2:1,all_=units.flatMap(u=>u.rows).filter(xlLive),tA=sum(all_),tP=sum(all_.filter(x=>x.pay=='Paid'));
 const gt=[{v:'GRAND TOTAL',s:XS.tlab},...(byM?[{v:'',s:XS.tblank}]:[])];
 [[all_.length,XS.tint],[all_.reduce((s,x)=>s+x.qty,0),XS.tint],[tA,XS.tmoney],[tP,XS.tmoney],[tA-tP,XS.tmoney]].forEach(([v,s],j)=>{const c=xc(k+j);gt.push({f:`SUM(${c}${a}:${c}${b})`,v,s})});
 srow(20,gt);const GT=base+units.length;
 srow(0,[]);srow(0,[]);const sg=Array(7).fill(null);sg[0]={v:'Prepared by: ____________________',s:XS.bold};sg[3]={v:'Checked by: ____________________',s:XS.bold};
 srow(22,sg);const sg2=Array(7).fill(null);sg2[0]={v:'Approved by: ____________________',s:XS.bold};srow(30,sg2);
 const summary={rows:S,cols:byM?[9,15,14,12,18,18,18]:[10,14,12,18,18,18],freeze:5,merges:['A1:G1','A2:G2','A3:G3',`A${GT}:${byM?'B':'A'}${GT}`].filter(m=>!/^A(\d+):A\1$/.test(m))};
 const sheets=[{name:'Orders',xml:xSheet(orders)},{name:'Summary',xml:xSheet(summary)}],NS=2;
 const files=[
 {name:'[Content_Types].xml',data:H+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')+'</Types>'},
 {name:'_rels/.rels',data:H+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'},
 {name:'xl/workbook.xml',data:H+'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'+sheets.map((s,i)=>`<sheet name="${xe(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')+'</sheets><definedNames>'+sheets.map((s,i)=>`<definedName name="_xlnm.Print_Titles" localSheetId="${i}">'${xe(s.name)}'!$5:$5</definedName>`).join('')+'</definedNames></workbook>'},
 {name:'xl/_rels/workbook.xml.rels',data:H+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')+`<Relationship Id="rId${NS+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`},
 {name:'xl/styles.xml',data:XSTYLES},...sheets.map((s,i)=>({name:`xl/worksheets/sheet${i+1}.xml`,data:s.xml}))];
 return zipStore(files)}
function xlSel(){const y=$('#xy')?$('#xy').value:'',m=$('#xm')?$('#xm').value:'';return xlGroups().filter(g=>(!y||g.y==y)&&(!m||g.m==m))}
function xlPrev(){const s=xlSel(),el=$('#xp'),b=$('#xgo');if(!el)return;const yr=$('#xs').value=='year',n=s.reduce((a,g)=>a+g.rows.length,0);
 const us=yr?[...new Set(s.map(g=>g.y))].map(y=>({l:String(y),rows:s.filter(g=>g.y==y).flatMap(g=>g.rows)})):s.map(g=>({l:MONTHS[g.m-1]+' '+g.y,rows:g.rows}));
 el.innerHTML=s.length?`<div style="padding:6px 0;border-bottom:1px solid var(--bd)"><b>Orders sheet:</b> all ${n} order${n==1?'':'s'}, listed one by one</div><div style="padding:6px 0 2px"><b>Summary sheet (per ${yr?'year':'month'}):</b></div>`+us.map(u=>{const L=u.rows.filter(xlLive);return`<div style="display:flex;justify-content:space-between;gap:10px;padding:5px 0;border-bottom:1px solid var(--bd)"><span>${u.l} · ${L.length} order${L.length==1?'':'s'}</span><span>${fmt(L.reduce((a,r)=>a+r.total,0))}</span></div>`}).join(''):'<div>No orders found for this selection.</div>';b.disabled=!s.length;b.style.opacity=s.length?1:.5}
function xlGo(){const s=xlSel();if(!s.length)return;const y=$('#xy').value,m=$('#xm').value,mode=$('#xs').value;
 const nm='AquaTrack_Orders_'+(y||'All-Years')+(m?'-'+String(m).padStart(2,'0'):'')+'_Summary-per-'+(mode=='year'?'Year':'Month')+'.xlsx',a=document.createElement('a');a.href=URL.createObjectURL(xlBook(s,mode));a.download=nm;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);$('#md').classList.remove('on')}
function exportOrders(){const g=xlGroups(),ys=[...new Set(g.map(x=>x.y))].sort((a,b)=>b-a);
 $('#fm').innerHTML=`<h3 style="color:var(--pri);margin:0 0 4px">Export Orders to Excel</h3><p style="margin:0 0 6px;font-size:12px">Creates an Excel file that lists every order one by one, followed by a summary per month or per year.</p>
 <label>Summary per</label><select id="xs" onchange="xlPrev()"><option value="month">Month</option><option value="year">Year</option></select><label>Year</label><select id="xy" onchange="xlPrev()"><option value="">All years</option>${ys.map(y=>`<option>${y}</option>`).join('')}</select>
 <label>Month</label><select id="xm" onchange="xlPrev()"><option value="">All months</option>${MONTHS.map((m,i)=>`<option value="${i+1}">${m}</option>`).join('')}</select>
 <label style="margin-top:14px">Will be included</label><div id="xp" style="font-size:13px"></div>
 <div class="bt"><button type="button" class="btn g" onclick="$('#md').classList.remove('on')">Cancel</button><button type="button" class="btn" id="xgo" onclick="xlGo()">Download Excel</button></div>`;
 $('#fm').onsubmit=e=>e.preventDefault();$('#md').classList.add('on');xlPrev()}

function bk(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(D)],{type:'application/json'}));a.download='aquatrack_procurement_backup.json';a.click()}
function rs(i){const f=i.files[0];if(!f)return;f.text().then(t=>{D=JSON.parse(t);save();location.reload()})}
/* ---------- Login & roles ---------- */
/* Demo accounts – change these (they live in this file, so this is a front-end gate only, not server security). */
const ACCOUNTS=[{u:'superadmin',p:'super123',role:'super',name:'Super Admin'},{u:'admin',p:'admin123',role:'admin',name:'Admin'}];
let USER=null;try{USER=JSON.parse(sessionStorage.getItem('aqua_user')||'null')}catch(e){}
const isSuper=()=>!!USER&&USER.role=='super';
/* Admin cannot open Supplier Management (or a supplier's page); Super Admin can open everything */
const canView=v=>isSuper()||!(v=='suppliers'||String(v).startsWith('sup:'));
/* Approvals & payments are Super Admin only */
const SUPER_ONLY={po:['Confirm','Cancel'],quo:['Reject'],inv:['Request Payment'],pq:['Pay','Cancel']};
const canAct=(t,l)=>isSuper()||!(SUPER_ONLY[t]||[]).includes(l);
/* Inventory & Branches are view-only for Admin */
const canAdd=t=>isSuper()||!isInv(t);
function applyRole(){const el=document.querySelector('#nav a[data-v=suppliers]');if(el)el.style.display=canView('suppliers')?'':'none';
 $('#un').textContent=USER?USER.name:'';$('#ur').textContent=USER?(USER.role=='super'?'Full access':'Limited access'):'';
 $('#lg').classList.toggle('on',!USER)}
function login(e){e.preventDefault();const u=$('#lu').value.trim().toLowerCase(),a=ACCOUNTS.find(x=>x.u==u&&x.p==$('#lp').value);
 if(!a){$('#le').textContent='Wrong username or password.';return false}
 USER={u:a.u,role:a.role,name:a.name};try{sessionStorage.setItem('aqua_user',JSON.stringify(USER))}catch(_){}
 $('#lp').value='';$('#le').textContent='';if(!canView(cur))cur='pdash';applyRole();go();return false}
function logout(){USER=null;try{sessionStorage.removeItem('aqua_user')}catch(e){}cur='dash';pOpen=fOpen=iOpen=false;$('#lu').value='';applyRole();go()}
applyRole();go();
