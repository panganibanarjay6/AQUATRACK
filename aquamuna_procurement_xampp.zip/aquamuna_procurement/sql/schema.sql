-- Aquamuna Procurement - database for XAMPP (MariaDB/MySQL)
-- Import this file in phpMyAdmin (Import tab) or run: mysql -u root < schema.sql

CREATE DATABASE IF NOT EXISTS `aquamuna_procurement` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `aquamuna_procurement`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(60) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM("super","admin") NOT NULL,
  `full_name` VARCHAR(120) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `app_meta` (
  `k` VARCHAR(60) PRIMARY KEY,
  `v` LONGTEXT NOT NULL
) ENGINE=InnoDB;

-- collection: suppliers
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `contact` VARCHAR(255) NULL,
  `phone` VARCHAR(255) NULL,
  `email` VARCHAR(255) NULL,
  `address` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: items
CREATE TABLE IF NOT EXISTS `items` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `category` VARCHAR(255) NULL,
  `unit` VARCHAR(255) NULL,
  `stock` DECIMAL(14,2) NULL,
  `reorder_level` DECIMAL(14,2) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: pl
CREATE TABLE IF NOT EXISTS `price_list` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `supplier_id` INT NULL,
  `item_id` INT NULL,
  `price` DECIMAL(14,2) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: pr
CREATE TABLE IF NOT EXISTS `purchase_requests` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `item_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `dept` VARCHAR(255) NULL,
  `branch_id` INT NULL,
  `req_date` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: rfq
CREATE TABLE IF NOT EXISTS `rfqs` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `pr_id` INT NULL,
  `item_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `supplier_id` INT NULL,
  `branch_id` INT NULL,
  `due_date` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: quo
CREATE TABLE IF NOT EXISTS `quotations` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `rfq_id` INT NULL,
  `supplier_id` INT NULL,
  `item_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `price` DECIMAL(14,2) NULL,
  `branch_id` INT NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: po
CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `supplier_id` INT NULL,
  `item_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `price` DECIMAL(14,2) NULL,
  `branch_id` INT NULL,
  `order_date` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `quotation_id` INT NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: gr
CREATE TABLE IF NOT EXISTS `goods_receipts` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `po_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `date_received` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `photo` LONGTEXT NULL,
  `photo_at` VARCHAR(255) NULL,
  `rider` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: inv
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `po_id` INT NULL,
  `amount` DECIMAL(14,2) NULL,
  `due_date` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: pq
CREATE TABLE IF NOT EXISTS `payment_requests` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `invoice_id` INT NULL,
  `amount` DECIMAL(14,2) NULL,
  `req_date` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `reason` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: rc
CREATE TABLE IF NOT EXISTS `payment_receipts` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `payment_request_id` INT NULL,
  `invoice_id` INT NULL,
  `amount` DECIMAL(14,2) NULL,
  `method` VARCHAR(255) NULL,
  `reference_no` VARCHAR(255) NULL,
  `date_paid` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: branches
CREATE TABLE IF NOT EXISTS `branches` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `is_warehouse` TINYINT(1) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: bs
CREATE TABLE IF NOT EXISTS `branch_stock` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `branch_id` INT NULL,
  `item_id` INT NULL,
  `stock` DECIMAL(14,2) NULL,
  `reorder_level` DECIMAL(14,2) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: dist
CREATE TABLE IF NOT EXISTS `distributions` (
  `id` INT NOT NULL PRIMARY KEY,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `created_on` VARCHAR(255) NULL,
  `branch_id` INT NULL,
  `item_id` INT NULL,
  `qty` DECIMAL(14,2) NULL,
  `pr_id` INT NULL,
  `date_issued` VARCHAR(255) NULL,
  `status` VARCHAR(255) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: msgs
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT NOT NULL PRIMARY KEY,
  `po_id` INT NULL,
  `from_side` VARCHAR(255) NULL,
  `sender_name` VARCHAR(255) NULL,
  `sender_user` VARCHAR(255) NULL,
  `body` LONGTEXT NULL,
  `sent_at` VARCHAR(255) NULL,
  `is_read` TINYINT(1) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- collection: log
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` INT NOT NULL PRIMARY KEY,
  `logged_at` VARCHAR(255) NULL,
  `action` VARCHAR(255) NULL,
  `record_type` VARCHAR(255) NULL,
  `doc_no` VARCHAR(255) NULL,
  `order_no` VARCHAR(255) NULL,
  `details` LONGTEXT NULL,
  `done_by` VARCHAR(255) NULL,
  `is_backfill` TINYINT(1) NULL,
  `extra` LONGTEXT NULL,
  `h` CHAR(32) NULL,
  `sort_pos` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

INSERT IGNORE INTO `users` (`username`,`password_hash`,`role`,`full_name`) VALUES
 ("superadmin","$2y$10$x5EW7cXDZ/Ju8Mhz0PvGMeBH2I3GCWxDaDomUoU.uJ.9BAH.o12YK","super","Super Admin"),
 ("admin","$2y$10$5DJNRA.T.JQT1OSRXjWgKuUygl8SGbgYOEvgEABSmnRXDNienyeYG","admin","Admin");
