<?php
// XAMPP defaults: user "root", empty password. Change here if yours differs.
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'aquamuna_procurement';
const DB_USER = 'root';
const DB_PASS = '';
